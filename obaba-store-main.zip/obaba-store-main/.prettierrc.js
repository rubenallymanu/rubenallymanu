module.exports = {
  endOfLine: 'lf',
  semi: true,
  singleQuote: true,
  jsxSingleQuote: false,
  bracketSpacing: true,
  useTabs: false,
  tabWidth: 2,
  printWidth: 100,
  arrowParens: 'always',
  trailingComma: 'all',
};
