declare module 'react-rapid-carousel';
declare module 'save-svg-as-png';
declare module '@infosimples/node_two_captcha';
