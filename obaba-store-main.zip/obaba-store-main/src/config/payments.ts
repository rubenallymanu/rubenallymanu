// 'va', 'qris', 'ewallet', 'cstore'
export const PAYMENT_CHANNEL_GROUPS_EXCEPTION = ['qris', 'cstore'];
