export const PRODUCTS_EXCEPTION = [
  'mobile-legends-gift-skin-item',
  'mobile-legends-hemat',
  'mobile-legends-charisma',
  'chimeraland',
  'hyper-front',
  'mobile-legends-joki',
  'pubg-mobile-indonesia-hemat',
];
