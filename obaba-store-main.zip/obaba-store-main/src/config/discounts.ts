type Discount = {
  slug: string;
  discount_percentage: number,
}
export const DISCOUNTS: Discount[] = [
  // {
  //   slug: 'mobile-legends',
  //   discount_percentage: 3,
  // },
  // {
  //   slug: 'mobile-legends-hemat',
  //   discount_percentage: 3,
  // },
];
