import { Product } from './product';

export type CategoryProducts = {
  name: string;
  products: Product[];
};
