import { Payment } from './payment';

export type PaymentChannels = Payment[];
