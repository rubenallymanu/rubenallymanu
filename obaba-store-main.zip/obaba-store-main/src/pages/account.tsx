export default function Account() {
  return <>Account</>;
}
