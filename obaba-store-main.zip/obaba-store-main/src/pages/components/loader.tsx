export function Loader() {
  return (
    <>
      {/* <section className="chakra-input__group just-pay-1k4960">
        <div className="chakra-input__left-element just-pay-r5ogvh">
          <svg
            stroke="currentColor"
            fill="currentColor"
            strokeWidth="0"
            viewBox="0 0 24 24"
            height="1em"
            width="1em"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g>
              <path fill="none" d="M0 0h24v24H0z" />
              <path d="M18.031 16.617l4.283 4.282-1.415 1.415-4.282-4.283A8.96 8.96 0 0 1 11 20c-4.968 0-9-4.032-9-9s4.032-9 9-9 9 4.032 9 9a8.96 8.96 0 0 1-1.969 5.617zm-2.006-.742A6.977 6.977 0 0 0 18 11c0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7a6.977 6.977 0 0 0 4.875-1.975l.15-.15z" />
            </g>
          </svg>
        </div>
        <input placeholder="Cari ..." className="chakra-input just-pay-tu0gy8" />
      </section> */}
      <div className="chakra-skeleton just-pay-gnpmxx" />
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-n21gh5">
        <div className="chakra-skeleton just-pay-1713xrk" />
        <div className="chakra-skeleton just-pay-1az71pm" />
        <div className="chakra-skeleton just-pay-1az71pm" />
      </div>
      <div className="chakra-stack just-pay-rj9zlw">
        <div className="chakra-skeleton just-pay-gnpmxx" />
      </div>
      <div className="chakra-stack just-pay-rj9zlw">
        <div className="chakra-skeleton just-pay-gnpmxx" />
      </div>
      <hr className="just-pay-z4a72a" />
      <section className="just-pay-1v7r4tf">
        <div className="just-pay-gmuwbf">
          <h2 className="chakra-heading just-pay-rr3zeo">Metode Pembayaran</h2>
        </div>
        <div className="chakra-stack just-pay-18drp0f">
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
        </div>
        <div className="chakra-stack just-pay-d4yp68">
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
          <div className="chakra-skeleton just-pay-13l4mi5" />
        </div>
      </section>
      <hr className="just-pay-z4a72a" />
      <footer className="just-pay-bjlvxy">
        <div className="just-pay-1t9439" />
        <div className="just-pay-1cttwf5">
          <div className="chakra-stack just-pay-1amf41o" />
        </div>
        <div className="just-pay-1serrm7">
          <p className="chakra-text just-pay-o0vwak" />
        </div>
      </footer>
    </>
  );
}

export default Loader;
